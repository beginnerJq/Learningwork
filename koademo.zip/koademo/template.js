const Koa = require('koa');
const Router = require("koa-router");
const app = new Koa;//实例化Koa
const router = new Router();//实例化路由
const render = require('koa-art-template');//art模板引擎
const path = require("path");
render(app, {
    root: path.join(__dirname, 'views'),//视图的位置
    extname: '.html',//后缀名
    debug: process.env.NODE_ENV !== 'production' //是否开启调试模式
});

router.get("/",async (ctx,next)=>{
    let list = ['111','222','333'];
    await ctx.render('template',{
        title:"<h1>hh</h1>",
        list
    });
});
app
.use(router.routes())
.use(router.allowedMethods());//自动设置响应头
app.listen(3000);