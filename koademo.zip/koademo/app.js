
//注意，我们需要在每一个路由render都要渲染公共数据
//使用中间件
/*
    ctx.state = {
        session : this.session,
        title:'app
    }
*/
const Koa = require('koa');
const Router = require("koa-router");
const views = require('koa-views');
const fetch = require('node-fetch'); //使用fetch
const Bluebird = require('bluebird');
fetch.Promise = Bluebird;

const app = new Koa;//实例化Koa
const router = new Router();//实例化路由

//第三方中间件
//app.use(views('views',{map:{ html : 'ejs'}}));
app.use(views('views', { extension: 'ejs' }));//使用模板引擎,后缀名是ejs
//配置公共信息
app.use(async (ctx,next)=>{
    ctx.state.userinfo = 'zhansan';
    await next();
});

//中间件
app.use(async (ctx,next) => {
    await next();
    if(ctx.status == 404){
        ctx.response.status = 404;
        ctx.body = "页面不存在";
    }else if(ctx.status == 500){
        ctx.response.status = 500;
        ctx.body = "服务器错误";
    }
});
router.get("/",async (ctx,next)=>{//根路由
    let booksJson;
    await fetch('http://localhost/basic/web/index.php?r=books/index')
    .then(res => res.json())
    .then(json => booksJson = json.dataProvider.query);
    
    await ctx.render('index',{ //render是异步
        booksJson
    });
});
router.get("/news",async (ctx,next)=>{
    let list = ['111','2222','3333'];
    let content = "<h2>这是一个h2</h2>";
    let num = 12;
    await ctx.render('news',{
        list,
        content,
        num
    });
    //ctx.body = "这是一个新闻路由";
});
app
.use(router.routes())
.use(router.allowedMethods());//自动设置响应头
app.listen(3000);