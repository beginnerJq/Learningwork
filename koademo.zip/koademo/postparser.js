const Koa = require('koa');
const Router = require("koa-router");
const views = require('koa-views');
var bodyParser = require('koa-bodyparser');//引入body解析模块
const static = require('koa-static');//静态web服务
const app = new Koa;//实例化Koa
const router = new Router();//实例化路由
app.use(static(//静态文件 找不到继续向下匹配 可以配置多个
    __dirname + '/static'
));
app.use(bodyParser());//解析post提交数据
app.use(views('views', { extension: 'ejs' }));//使用模板引擎,后缀名是ejs
router.get("/",async (ctx,next)=>{
   await ctx.render('postparser');
});
router.post("/doAdd",async (ctx,next)=>{
    console.log(ctx.request.body);
    ctx.body = "提交数据成功";
});
app
.use(router.routes())
.use(router.allowedMethods());//自动设置响应头
app.listen(3000);